int main()
{
    return 25;
}