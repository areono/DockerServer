#include <time.h>
#include <stdio.h>

int main () {
   clock();
   return 0;
}